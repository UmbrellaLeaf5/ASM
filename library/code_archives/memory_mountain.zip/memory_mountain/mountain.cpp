#include <algorithm>
#include <array>
#include <cinttypes>
#include <chrono>
#include <cmath>
#include <fstream>
#include <random>
#include <stdexcept>

#include "../nanobench.h"

using namespace std::chrono_literals;

constexpr uint64_t max_elems = 128'000'000;
constexpr uint64_t min_elems = 16'000;
constexpr uint64_t max_stride = 2'048;
constexpr uint64_t min_stride = 1;
constexpr uint64_t warm_up = 2;
constexpr auto min_epoch_time = 150ms;

std::array<int64_t, max_elems> data;

/** test - Iterate over first `elems` of `data` with
 *         `stride`, using 4 x 4 loop unrolling.
 */
int64_t test (int64_t elems, int64_t stride)
{
    int64_t sx2 = stride * 2;
    int64_t sx3 = stride * 3;
    int64_t sx4 = stride * 4;
    int64_t acc0 = 0;
    int64_t acc1 = 0;
    int64_t acc2 = 0;
    int64_t acc3 = 0;
    int64_t length = elems;
    int64_t limit = length - sx4;

    int64_t i = 0;
    // combine 4 elements at a time
    for (; i < limit; i += sx4)
    {
        acc0 += data[i];
        acc1 += data[i + stride];
        acc2 += data[i + sx2];
        acc3 += data[i + sx3];
    }

    // finish any remaining elements
    for (; i < length; ++i)
        acc0 += data[i];
    
    return (acc0 + acc1) + (acc2 + acc3);
}

auto range (uint64_t min, uint64_t max, int ratio, int n_sub)
{
    std::vector<uint64_t> vals;
    for (uint64_t x = min; x <= max; x *= ratio)
    {
        double dx = x / double(n_sub);
        for (int i = 0; i < n_sub; ++i)
        {
            uint64_t n = x + std::round(i * dx);
            if (vals.empty() || n != vals.back())  // prevent same values due to rounding
                vals.push_back(n);
        }
    }
    return vals;
}

void run (ankerl::nanobench::Bench& bench, int ratio, int n_sub)
{
    for (uint64_t elems : range(min_elems, max_elems, ratio, n_sub))
    {
        for (uint64_t stride : range(min_stride, max_stride, ratio, n_sub))
        {
            std::string elems_str = std::to_string(elems);
            std::string stride_str = std::to_string(stride);

            bench.context("nelems", elems_str)
                 .context("stride", stride_str)
                 .batch(elems * sizeof(uint64_t) / double(stride));

            bench.run(elems_str + "/" + stride_str, [elems, stride](){
                ankerl::nanobench::doNotOptimizeAway(test(elems, stride));
            });
        }
    }
}

void save_results (ankerl::nanobench::Bench& bench, const std::string& filename)
{
    std::ofstream ofs {filename};
    if (!ofs)
        throw std::runtime_error{"can't open file '" + filename + "'"};

    std::string templ = R"DELIM("batch";"unit";"nelems";"stride";"elapsed";"error %";"total"
{{#result}}{{batch}};"{{unit}}";{{context(nelems)}};{{context(stride)}};{{median(elapsed)}};{{medianAbsolutePercentError(elapsed)}};{{sumProduct(iterations, elapsed)}}
{{/result}})DELIM";

    ankerl::nanobench::templates::csv();
    bench.render(templ, ofs);
}

int main()
{
    std::random_device dev;
    std::uniform_int_distribution<uint64_t> ran{0, 1024};

    std::generate(data.begin(), data.end(), [&ran, &dev](){ return ran(dev); });

    auto bench = ankerl::nanobench::Bench();
    bench.title("memory mountain")
         .warmup(warm_up)
         .unit("byte")
         .minEpochTime(min_epoch_time);

    run(bench, 2, 4);

    save_results(bench, "mountain.csv");
}
