g++ -O3 -o prog -I.. ../nanobench.cpp mountain.cpp
